import { Component,OnInit,AfterViewInit,ViewChild } from '@angular/core';

import { Student } from './dtos/student';
import {MatTableDataSource} from '@angular/material/table';
import {MatPaginator} from '@angular/material/paginator';
import {MatSnackBar} from '@angular/material/snack-bar';
import {MatDialog} from '@angular/material/dialog';
import {MatButtonModule} from '@angular/material/button';
import { StudentService } from './services/student.service';

import { StudentAddEditComponent } from './student-add-edit/student-add-edit.component';
import { SafeResourceUrlWithIconOptions } from '@angular/material/icon';
import { StudentDeleteComponent } from './student-delete/student-delete.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit,AfterViewInit {
  displayedColumns:string[]=['firstname','lastname','mobile','email','nic'];
  dataStudent=new MatTableDataSource<Student>();

  @ViewChild(MatPaginator)paginator!:MatPaginator;

  constructor(
    private _snackbar:MatSnackBar,
    private _studentService:StudentService,
    private dialog:MatDialog
  ){

  }

  applyFilter(event:Event){
    const filtervalue=(event.target as HTMLInputElement).value;
    this.dataStudent.filter=filtervalue.trim().toLowerCase();
  }

  showStudents(){
    this._studentService.getList().subscribe({
      next:(data) =>{
        debugger
        if(data.status){
          this.dataStudent.data=data.value;
        }
      },
      error:(e)=>{}
    }) 
  }

  ngOnInit(): void {
    this.showStudents();
  }

  ngAfterViewInit(): void {
    this.dataStudent.paginator=this.paginator;
  }

  addnewStudent(){
    this.dialog.open(StudentAddEditComponent,{
      disableClose:true,
      width:"350px"
    }).afterClosed().subscribe(result=>{
      if(result==="created"){
        this.showStudents();
      }

    }
    )
  }

  editStudent(student:Student){
    debugger
    this.dialog.open(StudentAddEditComponent,{
      disableClose:true,
      data:student,
      width:"350px"
    }).afterClosed().subscribe(result=>{
      if(result==="edited"){
        this.showStudents();
      }

    }
    )
  }

  showAlert(msg: string, title: string) {
    this._snackbar.open(msg, title, {
      horizontalPosition: "end",
      verticalPosition: "top",
      duration: 3000
    })

  }

  deleteStudent(student:Student){
    this.dialog.open(StudentDeleteComponent,{
      disableClose:true,
      data:student
    }).afterClosed().subscribe(result=>{
      if(result==="delete"){
        this._studentService.delete(student.studentId).subscribe({
          next:(data)=>{
            if(data.status){
              this.showAlert("Student was deleted","success");
              this.showStudents();
            }
            else
              this.showAlert("Could not Delete","error");
          },
          error:(e)=>{}
        })
      }
    });
  }
}
